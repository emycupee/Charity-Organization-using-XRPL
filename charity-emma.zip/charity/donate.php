<?php require_once("config.php") ?>
<style>
     #uni_modal .modal-content>.modal-footer{
        display:none !important;
    }
    #uni_modal .modal-content>.modal-body{
        padding:unset !important;
    }
</style>

<div class="container-fluid py-2 px-3">
    <p>Your donation will be much appreciated and can help others. Thank you!</p>
    <div class="form-group">
        <input type="number" step="2" min="0" id="amount" class="form-control form-control-lg text-right">
        <center><small>Enter Donation Amount Here</small></center>
    </div>
    <div class="form-group">
    <center><span id="paypal-button"></span><br>
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
    </div>
    </center>
</div>
<script>

function payment_online(){
    $('[name="payment_method"]').val("Online Payment")
    $('[name="paid"]').val(1)
    $('#place_order').submit()
}
<?php
require 'vendor/autoload.php';

use XRPL\Client;
use XRPL\Payment;
use XRPL\PaymentFlags;
use XRPL\TrustSet;

$client = new Client('wss://s.altnet.rippletest.net:51233');

// This snippet walks us through partial payment.
// Reference: https://xrpl.org/partial-payments.html
function partialPayment(): void {
    global $client;

    $client->connect();

    // creating wallets as prerequisite
    $wallet1 = $client->fundWallet()->wallet;
    $wallet2 = $client->fundWallet()->wallet;

    // create a trustline to issue an IOU `FOO` and set limit on it.
    $trustSetTx = new TrustSet([
        'TransactionType' => 'TrustSet',
        'Account' => $wallet2->classicAddress,
        'LimitAmount' => [
            'currency' => 'FOO',
            'issuer' => $wallet1->classicAddress,
            'value' => '10000000000'
        ]
    ]);
    echo "Submitting a TrustSet transaction...\n";

    $trustSetRes = $client->submitAndWait($trustSetTx, ['wallet' => $wallet2]);
    echo "TrustSet transaction response:\n";
    print_r($trustSetRes);

    echo "Balances after trustline is created\n";
    echo "Balance of {$wallet1->classicAddress} is " . json_encode($client->getBalances($wallet1->classicAddress)) . "\n";
    echo "Balance of {$wallet2->classicAddress} is " . json_encode($client->getBalances($wallet2->classicAddress)) . "\n";

    // Initially, the issuer(wallet1) sends an amount to the other account(wallet2)
    $issueQuantity = '3840';
    $payment = new Payment([
        'TransactionType' => 'Payment',
        'Account' => $wallet1->classicAddress,
        'Amount' => [
            'currency' => 'FOO',
            'value' => $issueQuantity,
            'issuer' => $wallet1->classicAddress
        ],
        'Destination' => $wallet2->classicAddress
    ]);

    // submit payment
    $initialPayment = $client->submitAndWait($payment, ['wallet' => $wallet1]);
    echo "Initial payment response:" . json_encode($initialPayment) . "\n";

    echo "Balances after issuer(wallet1) sends IOU(\"FOO\") to wallet2\n";
    echo "Balance of {$wallet1->classicAddress} is " . json_encode($client->getBalances($wallet1->classicAddress)) . "\n";
    echo "Balance of {$wallet2->classicAddress} is " . json_encode($client->getBalances($wallet2->classicAddress)) . "\n";

    /*
    * Send money less than the amount specified on 2 conditions:
    * 1. Sender has less money than the aamount specified in the payment Tx.
    * 2. Sender has the tfPartialPayment flag activated.
    *
    * Other ways to specify flags are by using Hex code and decimal code.
    * eg. For partial payment(tfPartialPayment)
    * decimal ->131072, hex -> 0x00020000
    */
    $partialPaymentTx = new Payment([
        'TransactionType' => 'Payment',
        'Account' => $wallet2->classicAddress,
        'Amount' => [
            'currency' => 'FOO',
            'value' => '4000',
            'issuer' => $wallet1->classicAddress
        ],
        'Destination' => $wallet1->classicAddress,
        'Flags' => PaymentFlags::tfPartialPayment
    ]);

    // submit payment
    echo "Submitting a Partial Payment transaction...\n";
    $submitResponse = $client->submitAndWait($partialPaymentTx, ['wallet' => $wallet2]);
    echo "Partial Payment response: " . json_encode($submitResponse) . "\n";

    echo "Balances after Partial Payment, when wallet2 tried to send 4000 FOO's\n";
    echo "Balance of {$wallet1->classicAddress} is " . json_encode($client->getBalances($wallet1->classicAddress)) . "\n";
    echo "Balance of {$wallet2->classicAddress} is " . json_encode($client->getBalances($wallet2->classicAddress)) . "\n";

    $client->disconnect();
}

partialPayment();
?>

function donation_success(){
    start_loader()
    $.ajax({
        url:"classes/Master.php?f=save_donation",
        method:'POST',
        data:{amount:$('#amount').val()},
        dataType:'json',
        error:err=>{
            console.log(err)
            alert_toast("PayPay Process Was successfull but failed to record the amount into the database")
            end_loader();
        },success:function(resp){
            if(resp.status == 'success'){
                location.reload()
            }else{
                console.log(resp)
                alert_toast("PayPay Process Was successfull but failed to record the amount into the database")
            }
            end_loader();
        }
    })
}
</script>